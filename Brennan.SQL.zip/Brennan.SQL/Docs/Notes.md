## ADO Data Objects
|      Data Object     |  Notes   |
|----------------------|----------|
| DataSet              | contains one or more DataTable objects based on the resultset of the Command executed in the DataAdapter Fill method. |
| DataSet Object       | the container for a number of DataTable objects.  This is the object the  DataAdapter’s Fill method populates. |
| DataTable Object     | allows you to examine data through collections of rows and columns.  The DataSet contains one or more DataTable objects based on the resultset of the Command executed in the |
| DataRow Object       | provides access to the DataTable’s Rows collection. |
| DataColumn Object    | corresponds to a column in your table. |
| Constraint Object    | defines and enforces column constraints. |
| DataRelation Object  | defines the relations between DataTables in the DataSet object. |
| DataView Object      | allows you to examine DataTable data in different ways. |
